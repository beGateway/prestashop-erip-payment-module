<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{begatewayerip}prestashop>begatewayerip_4ef89c80592d148b28870c6a473f0feb'] = 'Система Расчёт (ЕРИП)';
$_MODULE['<{begatewayerip}prestashop>begatewayerip_e6e9222d2b99d8aea25d073a2e7e878f'] = 'Принимайте платежи через ЕРИП с bePaid.by';
$_MODULE['<{begatewayerip}prestashop>begatewayerip_48db8327ef2854af02e6a1c57e1acbea'] = 'cURL PHP расширение должно быть включено на сервере, чтобы использовать этот модуль.';
$_MODULE['<{begatewayerip}prestashop>begatewayerip_22d8ff492a13fa906407341fb129ccfc'] = 'Настройки сохранены';
$_MODULE['<{begatewayerip}prestashop>configuration_59c03620e217d5059ed1bcef985b0f67'] = 'Задайте настройки, чтобы принимать платежи через систему Расчет (ЕРИП)';
$_MODULE['<{begatewayerip}prestashop>configuration_24f6d0a5e981497218465d35e9702dae'] = 'ID магазина';
$_MODULE['<{begatewayerip}prestashop>configuration_5bb912794738b581d373fb67a44c90b7'] = 'Ключ магазина';
$_MODULE['<{begatewayerip}prestashop>configuration_d125d168a6899e57371eaac4505672b2'] = 'Домен API';
$_MODULE['<{begatewayerip}prestashop>configuration_318cb3d63237f08b18226fa35b598edd'] = 'Код услуги ЕРИП';
$_MODULE['<{begatewayerip}prestashop>configuration_f2e3f707d57e6441543b167c0e908dcd'] = 'Сохранить настройки';
$_MODULE['<{begatewayerip}prestashop>begatewayerip_26848989c34eb11b252746f847a87356'] = 'Оплатить через Расчёт (ЕРИП)';
$_MODULE['<{begatewayerip}prestashop>orderconfirmation_4b2dd68e39571aabe46081d9b90cf707'] = 'Ниже содержится инструкция как оплатить заказ';
$_MODULE['<{begatewayerip}prestashop>orderconfirmation_c489c8b5653b8065138f9140af0d3955'] = 'через систему Расчёт (ЕРИП).';
$_MODULE['<{begatewayerip}prestashop>orderconfirmation_717d25fe2cbcc893e3d4c19f5d2f2559'] = 'Если Вы осуществляете платеж в кассе банка, пожалуйста, сообщите кассиру о необходимости проведения платежа через систему Расчёт (ЕРИП).';
$_MODULE['<{begatewayerip}prestashop>orderconfirmation_1bc611522d107a5675f3b4444cf07eab'] = 'Для проведения платежа необходимо:';
$_MODULE['<{begatewayerip}prestashop>orderconfirmation_594d34bea9eac5e619047807672500c4'] = 'Выбрать пункт Система \"Расчёт\" (ЕРИП)';
$_MODULE['<{begatewayerip}prestashop>orderconfirmation_c320621f08ddfee7b230f69f0922fc03'] = 'Выбрать последовательно вкладки:';
$_MODULE['<{begatewayerip}prestashop>orderconfirmation_eef5a36447a450f2f40a119698459b9d'] = 'Ввести номер заказа';
$_MODULE['<{begatewayerip}prestashop>orderconfirmation_71b1048f0b23f55f9d17bda24dd5fc07'] = 'Проверить корректность информации';
$_MODULE['<{begatewayerip}prestashop>orderconfirmation_53da291662a41f10b7b0dcc922872342'] = 'Совершить платёж';
$_MODULE['<{begatewayerip}prestashop>orderconfirmation_fcfde6c1174a6a91dcead7f1efdb1af8'] = 'В случае вопрос по заказу свяжитесь с нашей';
$_MODULE['<{begatewayerip}prestashop>orderconfirmation_2f205a0edc4436984a6bb5d7a47d868a'] = 'службой поддержки';
$_MODULE['<{begatewayerip}prestashop>orderconfirmation_4005747e15c40cc0b6b682c641448948'] = 'Произошла ошибка при обработке Вашего заказа. Свяжитесь с нашей';
