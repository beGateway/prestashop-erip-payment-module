<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{begatewayerip}prestashop>begatewayerip_4ef89c80592d148b28870c6a473f0feb'] = 'Raschet (ERIP)';
$_MODULE['<{begatewayerip}prestashop>begatewayerip_e6e9222d2b99d8aea25d073a2e7e878f'] = 'Get ERIP payments with bePaid.by';
$_MODULE['<{begatewayerip}prestashop>begatewayerip_48db8327ef2854af02e6a1c57e1acbea'] = 'cURL extention must be enabled to use the module';
$_MODULE['<{begatewayerip}prestashop>begatewayerip_22d8ff492a13fa906407341fb129ccfc'] = 'Settings saved';
$_MODULE['<{begatewayerip}prestashop>configuration_59c03620e217d5059ed1bcef985b0f67'] = 'Setup settings to setup payments with Raschet (ERIP)';
$_MODULE['<{begatewayerip}prestashop>configuration_24f6d0a5e981497218465d35e9702dae'] = 'Shop Id';
$_MODULE['<{begatewayerip}prestashop>configuration_5bb912794738b581d373fb67a44c90b7'] = 'Shop key';
$_MODULE['<{begatewayerip}prestashop>configuration_d125d168a6899e57371eaac4505672b2'] = 'API domain';
$_MODULE['<{begatewayerip}prestashop>configuration_318cb3d63237f08b18226fa35b598edd'] = 'ERIP Service number';
$_MODULE['<{begatewayerip}prestashop>configuration_f2e3f707d57e6441543b167c0e908dcd'] = 'Save settings';
$_MODULE['<{begatewayerip}prestashop>begatewayerip_26848989c34eb11b252746f847a87356'] = 'Pay with ERIP';
