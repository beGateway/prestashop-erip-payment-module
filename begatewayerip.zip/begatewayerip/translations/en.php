<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{begatewayerip}prestashop>begatewayerip_4ef89c80592d148b28870c6a473f0feb'] = 'Raschet (ERIP)';
$_MODULE['<{begatewayerip}prestashop>begatewayerip_e6e9222d2b99d8aea25d073a2e7e878f'] = 'Get ERIP payments with bePaid.by';
$_MODULE['<{begatewayerip}prestashop>begatewayerip_48db8327ef2854af02e6a1c57e1acbea'] = 'cURL extention must be enabled to use the module';
$_MODULE['<{begatewayerip}prestashop>begatewayerip_22d8ff492a13fa906407341fb129ccfc'] = 'Settings saved';
$_MODULE['<{begatewayerip}prestashop>begatewayerip_26848989c34eb11b252746f847a87356'] = 'Pay with ERIP';
